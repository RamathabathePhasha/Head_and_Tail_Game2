import random

def head_or_tail():
    for _ in range(2): 
        choice = input("Guess 'Head' or 'Tail': ").capitalize()
        options = ["Head", "Tail"]

        if choice in options:
            result = random.choice(options)
            if choice == result:
                print("You won!")
                return
            else:
                print("You lost. The result was", result)
        else:
            print("Invalid choice. Please guess 'Head' or 'Tail'.")
    print("Out of chances. Better luck next time!")

head_or_tail()


